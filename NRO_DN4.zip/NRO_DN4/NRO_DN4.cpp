﻿#define _USE_MATH_DEFINES
#include <vector>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <chrono>

using namespace std;

int main() {
    vector<vector<double>> A;
    vector<double> b;
    string filename = "./datoteka_A_b.txt";
    ifstream infile(filename);

    if (!infile.is_open()) {
        cout << "Error: Cannot open file " << filename << endl;
        return 1;
    }

    string string_first_line;
    getline(infile, string_first_line);
    replace(string_first_line.begin(), string_first_line.end(), '=', ' ');
    istringstream iss(string_first_line);
    string nepomemben_del1, nepomemben_del2;
    int n;
    iss >> nepomemben_del1 >> nepomemben_del2 >> n;
    cout << "Velikost matrike A: " << n << "x" << n << endl;

    for (int iiA = 0; iiA < n; iiA++) {
        string line;
        getline(infile, line);
        replace(line.begin(), line.end(), ';', ' ');
        istringstream iss_column(line);
        vector<double> row;
        for (int column = 0; column < n; column++) {
            double element_a;
            iss_column >> element_a;
            row.push_back(element_a);
        }
        A.push_back(row);
    }

    string empty_line;
    getline(infile, empty_line);

    string string_line_b;
    getline(infile, string_line_b);
    replace(string_line_b.begin(), string_line_b.end(), '>', ' ');
    istringstream iss_b(string_line_b);
    int n_b;
    iss_b >> nepomemben_del1 >> nepomemben_del2 >> n_b;
    cout << "Velikost vektorja b: " << n_b << endl;

    for (int iib = 0; iib < n_b; iib++) {
        string line_b_element;
        getline(infile, line_b_element);
        istringstream iss_b_element(line_b_element);
        double b_element;
        iss_b_element >> b_element;
        b.push_back(b_element);
    }
    infile.close();

    // Gauss-Seidel metoda
    vector<double> T;
    for (int iiT = 0; iiT < n_b; iiT++) {
        T.push_back(100);
    }

    auto start_time = chrono::high_resolution_clock::now();

    for (int iter = 0; iter < 2000; iter++) {
        for (int i = 0; i < n; i++) {
            double sum = b[i];
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    sum -= A[i][j] * T[j];
                }
            }
            T[i] = sum / A[i][i];
        }
    }

    auto end_time = chrono::high_resolution_clock::now();
    chrono::duration<double> time_duration = end_time - start_time;

    double max_T = 0;
    for (int iiT = 0; iiT < n_b; iiT++) {
        cout << T[iiT] << endl;
        if (T[iiT] > max_T) {
            max_T = T[iiT];
        }
    }
    cout << "Serial Time: " << time_duration.count() << " seconds" << endl;
    cout << "Max. temperature: " << max_T << " degree C." << endl;

    return 0;
}